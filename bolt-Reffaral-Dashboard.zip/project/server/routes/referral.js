const express = require('express');
const { authenticateToken, mockUsers } = require('../middleware/auth');

const router = express.Router();

// Get user's referral data
router.get('/', authenticateToken, (req, res) => {
  const user = Array.from(mockUsers.values()).find(u => u.id === req.user.userId);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  // Mock referral data
  const referralData = {
    referralCode: user.referralCode,
    shareUrl: `https://renderwhizz.com/join/${user.referralCode}`,
    totalReferrals: user.totalReferrals,
    currentTier: calculateReferralTier(user.totalReferrals),
    commissionRate: calculateCommissionRate(user.totalReferrals),
    totalEarnings: user.totalEarnings,
    thisMonthEarnings: 23.45,
    referrals: generateMockReferrals(user.id)
  };

  res.json(referralData);
});

// Get referral tree (3 levels)
router.get('/tree', authenticateToken, (req, res) => {
  const user = Array.from(mockUsers.values()).find(u => u.id === req.user.userId);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  // Mock referral tree
  const tree = {
    user: {
      id: user.id,
      name: user.name,
      avatar: user.avatar,
      referrals: user.totalReferrals,
      earnings: user.totalEarnings
    },
    level1: [
      {
        id: 'ref1',
        name: 'Alice Johnson',
        avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
        referrals: 15,
        earnings: 45.67,
        joinedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
      },
      {
        id: 'ref2',
        name: 'Bob Smith',
        avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150',
        referrals: 8,
        earnings: 23.45,
        joinedAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000)
      }
    ],
    level2: [
      {
        id: 'ref3',
        name: 'Carol Davis',
        avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=150',
        referrals: 3,
        earnings: 12.34,
        referredBy: 'ref1'
      }
    ],
    level3: [
      {
        id: 'ref4',
        name: 'David Wilson',
        avatar: 'https://images.pexels.com/photos/697509/pexels-photo-697509.jpeg?auto=compress&cs=tinysrgb&w=150',
        referrals: 1,
        earnings: 5.67,
        referredBy: 'ref3'
      }
    ]
  };

  res.json(tree);
});

// Generate referral link
router.post('/generate-link', authenticateToken, (req, res) => {
  const user = Array.from(mockUsers.values()).find(u => u.id === req.user.userId);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  const shareUrl = `https://renderwhizz.com/join/${user.referralCode}`;
  
  res.json({
    referralCode: user.referralCode,
    shareUrl: shareUrl,
    qrCode: `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(shareUrl)}`
  });
});

function calculateReferralTier(totalReferrals) {
  if (totalReferrals >= 1000) return 5;
  if (totalReferrals >= 500) return 4;
  if (totalReferrals >= 200) return 3;
  if (totalReferrals >= 100) return 2;
  return 1;
}

function calculateCommissionRate(totalReferrals) {
  const tier = calculateReferralTier(totalReferrals);
  const rates = {
    1: 10, // 0-99: 10%
    2: 12, // 100-199: 12%
    3: 15, // 200-499: 15%
    4: 20, // 500-999: 20%
    5: 20  // 1000+: 20% (capped)
  };
  return rates[tier];
}

function generateMockReferrals(userId) {
  return [
    {
      id: 'ref1',
      name: 'Alice Johnson',
      email: 'alice@example.com',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
      joinedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
      totalRenders: 45,
      earnings: 45.67,
      status: 'active'
    },
    {
      id: 'ref2',
      name: 'Bob Smith',
      email: 'bob@example.com',
      avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150',
      joinedAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000),
      totalRenders: 23,
      earnings: 23.45,
      status: 'active'
    },
    {
      id: 'ref3',
      name: 'Carol Davis',
      email: 'carol@example.com',
      avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=150',
      joinedAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000),
      totalRenders: 12,
      earnings: 12.34,
      status: 'inactive'
    }
  ];
}

module.exports = router;