const express = require('express');
const { authenticateToken, requireAdmin, mockUsers } = require('../middleware/auth');

const router = express.Router();

// Apply admin authentication to all routes
router.use(authenticateToken);
router.use(requireAdmin);

// Get admin dashboard metrics
router.get('/metrics', (req, res) => {
  const metrics = {
    dailyActiveUsers: 1247,
    rendersToday: 3456,
    adFillRate: 94.2,
    totalUsers: 15678,
    totalRenders: 234567,
    totalRevenue: 12345.67,
    averageRenderSize: 2.4, // MB
    topCountries: [
      { country: 'United States', users: 4567, percentage: 29.1 },
      { country: 'United Kingdom', users: 2345, percentage: 15.0 },
      { country: 'Germany', users: 1876, percentage: 12.0 },
      { country: 'Canada', users: 1234, percentage: 7.9 },
      { country: 'Australia', users: 987, percentage: 6.3 }
    ],
    rendersByHour: Array.from({ length: 24 }, (_, i) => ({
      hour: i,
      renders: Math.floor(Math.random() * 200) + 50
    })),
    revenueByDay: Array.from({ length: 30 }, (_, i) => ({
      date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000),
      revenue: Math.floor(Math.random() * 500) + 200
    }))
  };

  res.json(metrics);
});

// Get all users with pagination and filters
router.get('/users', (req, res) => {
  const { page = 1, limit = 20, search = '', status = 'all' } = req.query;
  
  // Mock user data
  const allUsers = [
    {
      id: '1',
      name: 'John Doe',
      email: 'john@example.com',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150',
      whatsappVerified: true,
      totalRenders: 156,
      totalEarnings: 78.45,
      referrals: 23,
      status: 'active',
      lastLogin: new Date(Date.now() - 2 * 60 * 60 * 1000),
      createdAt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000)
    },
    {
      id: '2',
      name: 'Jane Smith',
      email: 'jane@example.com',
      avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
      whatsappVerified: true,
      totalRenders: 89,
      totalEarnings: 45.67,
      referrals: 12,
      status: 'active',
      lastLogin: new Date(Date.now() - 5 * 60 * 60 * 1000),
      createdAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000)
    },
    {
      id: '3',
      name: 'Bob Johnson',
      email: 'bob@example.com',
      avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150',
      whatsappVerified: false,
      totalRenders: 34,
      totalEarnings: 17.23,
      referrals: 5,
      status: 'inactive',
      lastLogin: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000),
      createdAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000)
    }
  ];

  // Apply filters
  let filteredUsers = allUsers;
  if (search) {
    filteredUsers = filteredUsers.filter(user => 
      user.name.toLowerCase().includes(search.toLowerCase()) ||
      user.email.toLowerCase().includes(search.toLowerCase())
    );
  }
  if (status !== 'all') {
    filteredUsers = filteredUsers.filter(user => user.status === status);
  }

  // Pagination
  const startIndex = (page - 1) * limit;
  const endIndex = startIndex + parseInt(limit);
  const paginatedUsers = filteredUsers.slice(startIndex, endIndex);

  res.json({
    users: paginatedUsers,
    pagination: {
      currentPage: parseInt(page),
      totalPages: Math.ceil(filteredUsers.length / limit),
      totalUsers: filteredUsers.length,
      hasNext: endIndex < filteredUsers.length,
      hasPrev: startIndex > 0
    }
  });
});

// Get specific user details
router.get('/users/:id', (req, res) => {
  const { id } = req.params;
  
  // Mock detailed user data
  const user = {
    id: id,
    name: 'John Doe',
    email: 'john@example.com',
    avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150',
    whatsappNumber: '+1234567890',
    whatsappVerified: true,
    role: 'user',
    status: 'active',
    totalRenders: 156,
    totalEarnings: 78.45,
    pendingEarnings: 12.34,
    referralCode: 'RWJOHN123',
    totalReferrals: 23,
    referralTier: 2,
    lastLogin: new Date(Date.now() - 2 * 60 * 60 * 1000),
    createdAt: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000),
    deviceFingerprint: 'fp_abc123def456',
    ipAddress: '192.168.1.100',
    loginHistory: [
      { timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000), ip: '192.168.1.100', device: 'Windows 11 Chrome' },
      { timestamp: new Date(Date.now() - 24 * 60 * 60 * 1000), ip: '192.168.1.100', device: 'Windows 11 Chrome' },
      { timestamp: new Date(Date.now() - 48 * 60 * 60 * 1000), ip: '192.168.1.101', device: 'Windows 11 Chrome' }
    ]
  };

  res.json(user);
});

// Update user (ban, change tier, etc.)
router.put('/users/:id', (req, res) => {
  const { id } = req.params;
  const { status, role, referralTier } = req.body;

  // Mock user update
  console.log(`Admin updating user ${id}:`, { status, role, referralTier });

  res.json({ 
    message: 'User updated successfully',
    changes: { status, role, referralTier }
  });
});

// Force logout user (revoke all tokens)
router.post('/users/:id/revoke', (req, res) => {
  const { id } = req.params;

  // Mock token revocation
  console.log(`Admin revoking all tokens for user ${id}`);

  res.json({ 
    message: 'All user tokens revoked successfully',
    userId: id,
    revokedAt: new Date()
  });
});

// Get referral network graph data
router.get('/referral-graph', (req, res) => {
  // Mock network graph data for D3.js visualization
  const graphData = {
    nodes: [
      { id: 'user1', name: 'John Doe', referrals: 23, earnings: 78.45, level: 0 },
      { id: 'user2', name: 'Alice Johnson', referrals: 15, earnings: 45.67, level: 1 },
      { id: 'user3', name: 'Bob Smith', referrals: 8, earnings: 23.45, level: 1 },
      { id: 'user4', name: 'Carol Davis', referrals: 3, earnings: 12.34, level: 2 },
      { id: 'user5', name: 'David Wilson', referrals: 1, earnings: 5.67, level: 3 }
    ],
    links: [
      { source: 'user1', target: 'user2' },
      { source: 'user1', target: 'user3' },
      { source: 'user2', target: 'user4' },
      { source: 'user4', target: 'user5' }
    ]
  };

  res.json(graphData);
});

// Get payout queue
router.get('/payouts', (req, res) => {
  const payouts = [
    {
      id: 'payout1',
      userId: '1',
      userName: 'John Doe',
      email: 'john@example.com',
      amount: 78.45,
      method: 'stripe',
      status: 'pending',
      requestedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
    },
    {
      id: 'payout2',
      userId: '2',
      userName: 'Jane Smith',
      email: 'jane@example.com',
      amount: 125.67,
      method: 'paypal',
      status: 'pending',
      requestedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000)
    }
  ];

  res.json(payouts);
});

// Process payout
router.post('/payouts/:id/process', (req, res) => {
  const { id } = req.params;

  // Mock payout processing
  console.log(`Processing payout ${id}`);

  res.json({
    message: 'Payout processed successfully',
    payoutId: id,
    processedAt: new Date(),
    status: 'completed'
  });
});

module.exports = router;