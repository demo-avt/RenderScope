const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Configure multer for file uploads
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../uploads');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, file.fieldname + '-' + uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: parseInt(process.env.MAX_FILE_SIZE) || 10 * 1024 * 1024 // 10MB
  },
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|gif|bmp|tiff|exr|hdr/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('Only image files are allowed'));
    }
  }
});

// Upload render endpoint
router.post('/', authenticateToken, upload.single('render'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const { adSessionId, whatsappNumber } = req.body;

    // Verify ad was completed (in production, check Redis/database)
    if (!adSessionId) {
      return res.status(400).json({ error: 'Ad session required' });
    }

    // Mock Twilio WhatsApp sending
    const whatsappResult = await sendToWhatsApp(whatsappNumber, req.file);

    // Create render record
    const renderRecord = {
      id: Date.now().toString(),
      userId: req.user.userId,
      filename: req.file.originalname,
      filepath: req.file.path,
      filesize: req.file.size,
      mimetype: req.file.mimetype,
      adSessionId: adSessionId,
      whatsappNumber: whatsappNumber,
      whatsappSent: whatsappResult.success,
      whatsappMessageId: whatsappResult.messageId,
      uploadedAt: new Date(),
      status: whatsappResult.success ? 'sent' : 'failed'
    };

    console.log('Render uploaded:', renderRecord);

    res.json({
      success: true,
      message: 'Render uploaded and sent to WhatsApp successfully!',
      render: {
        id: renderRecord.id,
        filename: renderRecord.filename,
        status: renderRecord.status,
        whatsappSent: renderRecord.whatsappSent,
        uploadedAt: renderRecord.uploadedAt
      }
    });

  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({ 
      error: 'Upload failed',
      message: error.message 
    });
  }
});

// Mock WhatsApp sending function
async function sendToWhatsApp(phoneNumber, file) {
  // Simulate Twilio API call
  return new Promise((resolve) => {
    setTimeout(() => {
      resolve({
        success: true,
        messageId: 'mock_message_' + Date.now(),
        status: 'sent'
      });
    }, 1000);
  });
}

// Get upload history
router.get('/history', authenticateToken, (req, res) => {
  // Mock upload history
  const history = [
    {
      id: '1',
      filename: 'bedroom_render_001.jpg',
      uploadedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      status: 'sent',
      whatsappSent: true,
      filesize: 2.4 * 1024 * 1024
    },
    {
      id: '2',
      filename: 'kitchen_render_002.jpg',
      uploadedAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
      status: 'sent',
      whatsappSent: true,
      filesize: 3.1 * 1024 * 1024
    }
  ];

  res.json(history);
});

module.exports = router;