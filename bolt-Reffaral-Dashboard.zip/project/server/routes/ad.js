const express = require('express');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();

// Mock ad sessions storage
const adSessions = new Map();

// Start ad session
router.post('/start', authenticateToken, (req, res) => {
  const sessionId = Date.now().toString();
  const adUnit = {
    id: sessionId,
    userId: req.user.userId,
    type: 'rewarded_video',
    duration: 30, // seconds
    reward: 0.05, // $0.05 per ad
    startedAt: new Date(),
    completed: false
  };

  adSessions.set(sessionId, adUnit);

  // Mock ad creative URLs
  const adCreatives = [
    'https://images.pexels.com/photos/3184291/pexels-photo-3184291.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/3184292/pexels-photo-3184292.jpeg?auto=compress&cs=tinysrgb&w=800',
    'https://images.pexels.com/photos/3184293/pexels-photo-3184293.jpeg?auto=compress&cs=tinysrgb&w=800'
  ];

  res.json({
    sessionId,
    adUrl: adCreatives[Math.floor(Math.random() * adCreatives.length)],
    duration: adUnit.duration,
    reward: adUnit.reward,
    message: 'Watch this ad to unlock render sending'
  });
});

// Complete ad session
router.post('/finish', authenticateToken, (req, res) => {
  const { sessionId, watchTime } = req.body;
  
  const adSession = adSessions.get(sessionId);
  
  if (!adSession) {
    return res.status(404).json({ error: 'Ad session not found' });
  }

  if (adSession.userId !== req.user.userId) {
    return res.status(403).json({ error: 'Unauthorized ad session' });
  }

  if (adSession.completed) {
    return res.status(400).json({ error: 'Ad already completed' });
  }

  // Verify minimum watch time (90% of ad duration)
  const minWatchTime = adSession.duration * 0.9;
  if (watchTime < minWatchTime) {
    return res.status(400).json({ 
      error: 'Ad not watched completely',
      required: minWatchTime,
      watched: watchTime
    });
  }

  // Mark as completed
  adSession.completed = true;
  adSession.completedAt = new Date();
  adSession.watchTime = watchTime;

  // In production, this would update user earnings in database
  console.log(`User ${req.user.userId} earned $${adSession.reward} from ad ${sessionId}`);

  res.json({
    success: true,
    reward: adSession.reward,
    message: 'Ad completed successfully! You can now send your render.',
    canUpload: true
  });
});

// Get ad statistics
router.get('/stats', authenticateToken, (req, res) => {
  // Mock ad statistics
  const stats = {
    totalAdsWatched: 156,
    totalEarnings: 7.80,
    averageWatchTime: 28.5,
    completionRate: 94.2,
    thisWeek: {
      adsWatched: 23,
      earnings: 1.15
    },
    thisMonth: {
      adsWatched: 89,
      earnings: 4.45
    }
  };

  res.json(stats);
});

module.exports = router;