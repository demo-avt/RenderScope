const express = require('express');
const { authenticateToken, mockUsers } = require('../middleware/auth');

const router = express.Router();

// Get current user profile
router.get('/me', authenticateToken, (req, res) => {
  const user = Array.from(mockUsers.values()).find(u => u.id === req.user.userId);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  res.json({
    id: user.id,
    email: user.email,
    name: user.name,
    avatar: user.avatar,
    whatsappNumber: user.whatsappNumber,
    whatsappVerified: user.whatsappVerified,
    role: user.role,
    referralCode: user.referralCode,
    totalEarnings: user.totalEarnings,
    pendingEarnings: user.pendingEarnings,
    totalReferrals: user.totalReferrals,
    referralTier: user.referralTier,
    createdAt: user.createdAt
  });
});

// Update user profile
router.put('/profile', authenticateToken, (req, res) => {
  const { name, whatsappNumber } = req.body;
  const user = Array.from(mockUsers.values()).find(u => u.id === req.user.userId);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  if (name) user.name = name;
  if (whatsappNumber) user.whatsappNumber = whatsappNumber;

  mockUsers.set(user.email, user);

  res.json({ message: 'Profile updated successfully' });
});

// Get user's render history
router.get('/renders', authenticateToken, (req, res) => {
  // Mock render history
  const renders = [
    {
      id: '1',
      filename: 'bedroom_render_001.jpg',
      thumbnail: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=300',
      uploadedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
      adWatched: true,
      status: 'sent',
      whatsappSent: true
    },
    {
      id: '2',
      filename: 'kitchen_render_002.jpg',
      thumbnail: 'https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg?auto=compress&cs=tinysrgb&w=300',
      uploadedAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
      adWatched: true,
      status: 'sent',
      whatsappSent: true
    },
    {
      id: '3',
      filename: 'living_room_003.jpg',
      thumbnail: 'https://images.pexels.com/photos/1571453/pexels-photo-1571453.jpeg?auto=compress&cs=tinysrgb&w=300',
      uploadedAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
      adWatched: true,
      status: 'sent',
      whatsappSent: true
    }
  ];

  res.json(renders);
});

// Get user's earnings breakdown
router.get('/earnings', authenticateToken, (req, res) => {
  const user = Array.from(mockUsers.values()).find(u => u.id === req.user.userId);
  
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  // Mock earnings data
  const earnings = {
    lifetime: user.totalEarnings,
    pending: user.pendingEarnings,
    thisMonth: 45.67,
    lastPayout: 125.00,
    nextPayoutDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
    payoutThreshold: 50.00,
    history: [
      { date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), amount: 125.00, status: 'paid' },
      { date: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000), amount: 89.50, status: 'paid' },
      { date: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000), amount: 156.75, status: 'paid' }
    ]
  };

  res.json(earnings);
});

module.exports = router;