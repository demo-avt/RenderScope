const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const { rateLimitRefresh, mockUsers } = require('../middleware/auth');

const router = express.Router();

// Mock Google OAuth endpoint
router.post('/google', async (req, res) => {
  try {
    const { googleToken } = req.body;
    
    // Mock Google token verification
    const mockGoogleUser = {
      id: 'google_123456789',
      email: 'user@example.com',
      name: 'John Doe',
      picture: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150'
    };

    // Check if user exists or create new one
    let user = mockUsers.get(mockGoogleUser.email);
    if (!user) {
      user = {
        id: Date.now().toString(),
        googleId: mockGoogleUser.id,
        email: mockGoogleUser.email,
        name: mockGoogleUser.name,
        avatar: mockGoogleUser.picture,
        whatsappNumber: null,
        whatsappVerified: false,
        role: 'user',
        referralCode: generateReferralCode(),
        referredBy: null,
        totalEarnings: 0,
        pendingEarnings: 0,
        totalReferrals: 0,
        referralTier: 0,
        createdAt: new Date(),
        lastLogin: new Date()
      };
      mockUsers.set(user.email, user);
    } else {
      user.lastLogin = new Date();
    }

    // Generate tokens
    const accessToken = jwt.sign(
      { 
        userId: user.id, 
        email: user.email, 
        role: user.role,
        jti: Date.now().toString()
      },
      process.env.JWT_SECRET || 'mock-secret',
      { expiresIn: '15m' }
    );

    const refreshToken = jwt.sign(
      { 
        userId: user.id, 
        tokenFamily: Date.now().toString()
      },
      process.env.JWT_REFRESH_SECRET || 'mock-refresh-secret',
      { expiresIn: '7d' }
    );

    // Set refresh token as httpOnly cookie
    res.cookie('refreshToken', refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000 // 7 days
    });

    res.json({
      accessToken,
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        avatar: user.avatar,
        whatsappVerified: user.whatsappVerified,
        role: user.role,
        referralCode: user.referralCode
      }
    });
  } catch (error) {
    console.error('Google auth error:', error);
    res.status(500).json({ error: 'Authentication failed' });
  }
});

// Refresh token endpoint
router.post('/refresh', rateLimitRefresh, (req, res) => {
  try {
    const refreshToken = req.cookies.refreshToken;
    
    if (!refreshToken) {
      return res.status(401).json({ error: 'Refresh token required' });
    }

    const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_SECRET || 'mock-refresh-secret');
    const user = Array.from(mockUsers.values()).find(u => u.id === decoded.userId);
    
    if (!user) {
      return res.status(403).json({ error: 'Invalid refresh token' });
    }

    // Generate new access token
    const accessToken = jwt.sign(
      { 
        userId: user.id, 
        email: user.email, 
        role: user.role,
        jti: Date.now().toString()
      },
      process.env.JWT_SECRET || 'mock-secret',
      { expiresIn: '15m' }
    );

    // Generate new refresh token (rotation)
    const newRefreshToken = jwt.sign(
      { 
        userId: user.id, 
        tokenFamily: decoded.tokenFamily
      },
      process.env.JWT_REFRESH_SECRET || 'mock-refresh-secret',
      { expiresIn: '7d' }
    );

    res.cookie('refreshToken', newRefreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production',
      sameSite: 'strict',
      maxAge: 7 * 24 * 60 * 60 * 1000
    });

    res.json({ accessToken });
  } catch (error) {
    res.status(403).json({ error: 'Invalid refresh token' });
  }
});

// Logout endpoint
router.post('/logout', (req, res) => {
  res.clearCookie('refreshToken');
  res.json({ message: 'Logged out successfully' });
});

// WhatsApp verification
router.post('/verify-whatsapp', (req, res) => {
  const { phoneNumber } = req.body;
  
  // Mock Twilio verification
  res.json({ 
    message: 'Verification code sent',
    verificationSid: 'mock_verification_sid'
  });
});

router.post('/confirm-whatsapp', (req, res) => {
  const { phoneNumber, code } = req.body;
  
  // Mock verification confirmation
  if (code === '123456') {
    res.json({ 
      message: 'WhatsApp verified successfully',
      verified: true
    });
  } else {
    res.status(400).json({ error: 'Invalid verification code' });
  }
});

function generateReferralCode() {
  return 'RW' + Math.random().toString(36).substring(2, 8).toUpperCase();
}

module.exports = router;