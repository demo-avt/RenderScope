# RenderWhizz - Web Application Prototype

A comprehensive web application prototype for the RenderWhizz ecosystem - a 3ds Max & Unreal Engine plugin platform with ad-monetized WhatsApp render sharing.

## 🎯 Overview

RenderWhizz is a revolutionary platform that bridges 3D rendering workflows with monetization through rewarded ads and referral systems. Users watch non-skippable ads to unlock WhatsApp sharing of their renders, while earning through a tiered referral program.

## 🚀 Features

### User Dashboard
- **Profile Management**: Google OAuth authentication, WhatsApp verification
- **Render Gallery**: Upload, view, and manage render history
- **Ad Integration**: Watch rewarded ads to unlock render sharing
- **Earnings Tracking**: Real-time earnings, payout management
- **Referral System**: Multi-tier commission structure (10-20%)

### Admin Dashboard
- **User Management**: View, ban, moderate user accounts
- **Analytics**: DAU, render metrics, revenue tracking
- **Payout Processing**: Bulk payout management via Stripe/PayPal
- **System Monitoring**: Real-time platform health metrics

### Security Features
- **JWT Authentication**: RS256 tokens with 15-minute TTL
- **Refresh Token Rotation**: AES-256-GCM encrypted, single-use
- **Rate Limiting**: 100 refresh calls per 15 minutes
- **Device Fingerprinting**: One account per device policy

## 🛠 Tech Stack

### Frontend
- **React 18** with TypeScript
- **Tailwind CSS** for styling
- **React Router** for navigation
- **Recharts** for data visualization
- **Lucide React** for icons

### Backend
- **Node.js 20** with Express
- **JWT** for authentication
- **MongoDB Atlas** for data storage
- **Redis** for session management
- **Stripe Connect** for payouts

### Development
- **Vite** for build tooling
- **ESLint** for code quality
- **TypeScript** for type safety

## 📦 Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd renderwhizz
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Environment Setup**
   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

4. **Start Development**
   ```bash
   # Frontend (Vite dev server)
   npm run dev

   # Backend (Node.js server)
   npm run server:dev
   ```

## 🔧 Configuration

### Environment Variables

```env
# Server Configuration
PORT=3001
NODE_ENV=development

# Database
MONGODB_URI=mongodb://localhost:27017/renderwhizz
REDIS_URL=redis://localhost:6379

# JWT Configuration
JWT_SECRET=your-super-secret-jwt-key-here
JWT_REFRESH_SECRET=your-super-secret-refresh-key-here

# Google OAuth
GOOGLE_CLIENT_ID=your-google-client-id
GOOGLE_CLIENT_SECRET=your-google-client-secret

# Twilio (WhatsApp)
TWILIO_ACCOUNT_SID=your-twilio-account-sid
TWILIO_AUTH_TOKEN=your-twilio-auth-token
TWILIO_VERIFY_SERVICE_SID=your-twilio-verify-service-sid

# Stripe
STRIPE_SECRET_KEY=sk_test_your-stripe-secret-key
STRIPE_WEBHOOK_SECRET=whsec_your-webhook-secret

# Frontend URL
FRONTEND_URL=http://localhost:5173
```

## 🎨 UI Components

### Dashboard Layouts
- **Responsive Design**: Mobile-first approach with breakpoints
- **Dark Mode Support**: System preference detection
- **Loading States**: Skeleton screens and spinners
- **Error Boundaries**: Graceful error handling

### Data Visualization
- **Revenue Charts**: Line charts for earnings trends
- **User Analytics**: Bar charts for activity metrics
- **Referral Trees**: Network graphs for referral visualization
- **Real-time Updates**: Live data refresh capabilities

## 🔐 Security Implementation

### Authentication Flow
1. **Google OAuth**: Secure third-party authentication
2. **JWT Tokens**: Short-lived access tokens (15 min)
3. **Refresh Rotation**: Automatic token renewal
4. **Session Management**: Redis-backed session storage

### Data Protection
- **Encryption**: AES-256-GCM for sensitive data
- **HTTPS Only**: TLS 1.3 for all communications
- **CORS Policy**: Strict origin validation
- **Rate Limiting**: API endpoint protection

## 💰 Monetization Model

### Referral Tiers
| Referrals | Base Rate | Bonus | Total Commission |
|-----------|-----------|-------|------------------|
| 0-99      | 10%       | 0%    | 10%              |
| 100-199   | 10%       | 2%    | 12%              |
| 200-499   | 10%       | 5%    | 15%              |
| 500-999   | 10%       | 10%   | 20%              |
| 1000+     | 10%       | 10%   | 20% (capped)     |

### Payout System
- **Minimum Threshold**: $50.00
- **Payment Methods**: Stripe Connect, PayPal
- **Processing Schedule**: 1st and 15th of each month
- **Fraud Protection**: Device fingerprinting, anomaly detection

## 🚀 Deployment

### Production Build
```bash
# Build frontend
npm run build

# Start production server
npm start
```

### cPanel Deployment
1. Upload built files to public_html
2. Configure Node.js app in cPanel
3. Set environment variables
4. Enable SSL certificate
5. Configure domain routing

## 📊 API Endpoints

### Authentication
- `POST /api/auth/google` - Google OAuth login
- `POST /api/auth/refresh` - Token refresh
- `POST /api/auth/logout` - User logout

### User Management
- `GET /api/user/me` - Get user profile
- `PUT /api/user/profile` - Update profile
- `GET /api/user/renders` - Render history
- `GET /api/user/earnings` - Earnings data

### Ad System
- `POST /api/ad/start` - Start ad session
- `POST /api/ad/finish` - Complete ad viewing
- `GET /api/ad/stats` - Ad statistics

### File Upload
- `POST /api/upload` - Upload render file
- `GET /api/upload/history` - Upload history

### Admin
- `GET /api/admin/metrics` - Platform metrics
- `GET /api/admin/users` - User management
- `GET /api/admin/payouts` - Payout queue

## 🧪 Testing

### Demo Mode
The application includes a demo mode with:
- Mock authentication (no real Google OAuth required)
- Sample data for all features
- Simulated API responses
- Interactive UI components

### Test Accounts
- **User**: Any Google account (mocked)
- **Admin**: Set `role: 'admin'` in mock data

## 📱 Mobile Support

- **Responsive Design**: Optimized for all screen sizes
- **Touch Interactions**: Mobile-friendly UI components
- **Progressive Web App**: PWA capabilities ready
- **Offline Support**: Service worker implementation ready

## 🔮 Future Enhancements

### Plugin Integration
- Native 3ds Max plugin (.dlz/.ms)
- Unreal Engine plugin (.uplugin)
- Real-time render detection
- Automatic file upload

### Advanced Features
- **AI-Powered**: Render quality analysis
- **Social Features**: Community sharing, likes, comments
- **Marketplace**: Render asset trading
- **Analytics**: Advanced user behavior tracking

## 📄 License

This project is proprietary software. All rights reserved.

## 🤝 Contributing

This is a prototype for demonstration purposes. For production implementation, please contact the development team.

## 📞 Support

For technical support or questions about the RenderWhizz platform, please contact:
- Email: support@renderwhizz.com
- Documentation: https://docs.renderwhizz.com
- Status Page: https://status.renderwhizz.com

---

**RenderWhizz v1.0 GA** - Revolutionizing 3D rendering workflows with smart monetization.