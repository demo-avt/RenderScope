import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

interface User {
  id: string;
  email: string;
  name: string;
  avatar: string;
  whatsappVerified: boolean;
  role: 'user' | 'admin';
  referralCode: string;
}

interface AuthContextType {
  user: User | null;
  isGuest: boolean;
  loading: boolean;
  login: (googleToken: string) => Promise<void>;
  loginAsGuest: () => void;
  logout: () => void;
  refreshToken: () => Promise<string | null>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

interface AuthProviderProps {
  children: ReactNode;
}

export const AuthProvider: React.FC<AuthProviderProps> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [isGuest, setIsGuest] = useState(false);
  const [loading, setLoading] = useState(true);
  const [accessToken, setAccessToken] = useState<string | null>(null);

  useEffect(() => {
    // Check for stored user data
    const demoUser = localStorage.getItem('demoUser');
    const guestMode = localStorage.getItem('guestMode');
    
    if (demoUser) {
      try {
        const userData = JSON.parse(demoUser);
        setUser(userData);
        setAccessToken('demo-access-token');
        setIsGuest(guestMode === 'true');
      } catch (error) {
        console.error('Error parsing demo user:', error);
      }
    }
    setLoading(false);
  }, []);

  const login = async (googleToken: string) => {
    try {
      const mockUser: User = {
        id: '1',
        email: 'demo@renderwhizz.com',
        name: 'Demo User',
        avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150',
        whatsappVerified: true,
        role: 'user',
        referralCode: 'RWDEMO123'
      };
      
      const mockToken = 'demo-access-token';
      
      setAccessToken(mockToken);
      setUser(mockUser);
      setIsGuest(false);
      localStorage.setItem('accessToken', mockToken);
      localStorage.setItem('demoUser', JSON.stringify(mockUser));
      localStorage.removeItem('guestMode');
    } catch (error) {
      console.error('Login error:', error);
      throw error;
    }
  };

  const loginAsGuest = () => {
    const guestUser: User = {
      id: 'guest',
      email: 'guest@renderwhizz.com',
      name: 'Guest User',
      avatar: 'https://images.pexels.com/photos/220453/pexels-photo-220453.jpeg?auto=compress&cs=tinysrgb&w=150',
      whatsappVerified: false,
      role: 'user',
      referralCode: 'GUEST123'
    };
    
    setUser(guestUser);
    setIsGuest(true);
    setAccessToken('guest-token');
    localStorage.setItem('demoUser', JSON.stringify(guestUser));
    localStorage.setItem('guestMode', 'true');
  };
  const logout = async () => {
    try {
      await fetch('/api/auth/logout', {
        method: 'POST',
        credentials: 'include',
      });
    } catch (error) {
      console.error('Logout error:', error);
    } finally {
      setAccessToken(null);
      setUser(null);
      setIsGuest(false);
      localStorage.removeItem('demoUser');
      localStorage.removeItem('guestMode');
      localStorage.removeItem('accessToken');
    }
  };

  const refreshToken = async (): Promise<string | null> => {
    try {
      const response = await fetch('/api/auth/refresh', {
        method: 'POST',
        credentials: 'include',
      });

      if (!response.ok) {
        return null; // Silently fail refresh attempts
      }

      const data = await response.json();
      setAccessToken(data.accessToken);

      // Get user data if we don't have it
      if (!user && data.accessToken) {
        const userResponse = await fetch('/api/user/me', {
          headers: {
            'Authorization': `Bearer ${data.accessToken}`,
          },
        });

        if (userResponse.ok) {
          const userData = await userResponse.json();
          setUser(userData);
        }
      }

      return data.accessToken;
    } catch (error) {
      setAccessToken(null);
      setUser(null);
      return null;
    }
  };

  // Auto-refresh token before expiry
  useEffect(() => {
    if (accessToken) {
      const interval = setInterval(() => {
        refreshToken();
      }, 14 * 60 * 1000); // Refresh every 14 minutes (token expires in 15)

      return () => clearInterval(interval);
    }
  }, [accessToken]);

  const value = {
    user,
    isGuest,
    loading,
    login,
    loginAsGuest,
    logout,
    refreshToken,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// Helper hook to get authenticated fetch function
export const useAuthenticatedFetch = () => {
  const { refreshToken } = useAuth();

  return async (url: string, options: RequestInit = {}) => {
    let token = localStorage.getItem('accessToken');

    const makeRequest = async (authToken: string | null) => {
      return fetch(url, {
        ...options,
        headers: {
          ...options.headers,
          ...(authToken && { 'Authorization': `Bearer ${authToken}` }),
        },
      });
    };

    let response = await makeRequest(token);

    // If unauthorized, try to refresh token
    if (response.status === 401) {
      const newToken = await refreshToken();
      if (newToken) {
        localStorage.setItem('accessToken', newToken);
        response = await makeRequest(newToken);
      }
    }

    return response;
  };
};