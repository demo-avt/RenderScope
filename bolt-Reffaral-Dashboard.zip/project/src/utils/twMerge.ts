import { twMerge } from 'tailwind-merge';

export { twMerge };