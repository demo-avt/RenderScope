import React, { useState, useEffect } from 'react';
import { 
  DollarSign, 
  Download, 
  CheckCircle, 
  Clock, 
  AlertTriangle,
  CreditCard,
  Filter,
  Search
} from 'lucide-react';

interface Payout {
  id: string;
  userId: string;
  userName: string;
  email: string;
  amount: number;
  method: 'stripe' | 'paypal';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  requestedAt: Date;
  processedAt?: Date;
}

const AdminPayouts: React.FC = () => {
  const [payouts, setPayouts] = useState<Payout[]>([]);
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'processing' | 'completed' | 'failed'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedPayouts, setSelectedPayouts] = useState<string[]>([]);

  useEffect(() => {
    fetchPayouts();
  }, []);

  const fetchPayouts = async () => {
    // Mock payout data
    const mockPayouts: Payout[] = [
      {
        id: 'payout1',
        userId: '1',
        userName: 'John Doe',
        email: 'john@example.com',
        amount: 78.45,
        method: 'stripe',
        status: 'pending',
        requestedAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
      },
      {
        id: 'payout2',
        userId: '2',
        userName: 'Jane Smith',
        email: 'jane@example.com',
        amount: 125.67,
        method: 'paypal',
        status: 'pending',
        requestedAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000)
      },
      {
        id: 'payout3',
        userId: '3',
        userName: 'Bob Johnson',
        email: 'bob@example.com',
        amount: 89.23,
        method: 'stripe',
        status: 'completed',
        requestedAt: new Date(Date.now() - 10 * 24 * 60 * 60 * 1000),
        processedAt: new Date(Date.now() - 8 * 24 * 60 * 60 * 1000)
      },
      {
        id: 'payout4',
        userId: '4',
        userName: 'Alice Wilson',
        email: 'alice@example.com',
        amount: 156.78,
        method: 'paypal',
        status: 'processing',
        requestedAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000)
      },
      {
        id: 'payout5',
        userId: '5',
        userName: 'Charlie Brown',
        email: 'charlie@example.com',
        amount: 67.89,
        method: 'stripe',
        status: 'failed',
        requestedAt: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000)
      }
    ];

    setPayouts(mockPayouts);
  };

  const handleProcessPayout = async (payoutId: string) => {
    console.log(`Processing payout ${payoutId}`);
    // In production, make API call
    setPayouts(prev => prev.map(p => 
      p.id === payoutId 
        ? { ...p, status: 'completed', processedAt: new Date() }
        : p
    ));
  };

  const handleBulkProcess = async () => {
    console.log(`Processing ${selectedPayouts.length} payouts`);
    // In production, make API call
    setPayouts(prev => prev.map(p => 
      selectedPayouts.includes(p.id)
        ? { ...p, status: 'completed', processedAt: new Date() }
        : p
    ));
    setSelectedPayouts([]);
  };

  const exportPayouts = () => {
    const csvContent = [
      ['ID', 'User', 'Email', 'Amount', 'Method', 'Status', 'Requested', 'Processed'].join(','),
      ...filteredPayouts.map(p => [
        p.id,
        p.userName,
        p.email,
        p.amount,
        p.method,
        p.status,
        p.requestedAt.toISOString(),
        p.processedAt?.toISOString() || ''
      ].join(','))
    ].join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'payouts.csv';
    a.click();
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'processing':
        return <Clock className="w-4 h-4 text-blue-500" />;
      case 'pending':
        return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'failed':
        return <AlertTriangle className="w-4 h-4 text-red-500" />;
      default:
        return <Clock className="w-4 h-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed':
        return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200';
      case 'processing':
        return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200';
      case 'failed':
        return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200';
      default:
        return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200';
    }
  };

  const filteredPayouts = payouts.filter(payout => {
    const matchesSearch = payout.userName.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         payout.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || payout.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const totalPending = payouts.filter(p => p.status === 'pending').reduce((sum, p) => sum + p.amount, 0);
  const totalProcessing = payouts.filter(p => p.status === 'processing').reduce((sum, p) => sum + p.amount, 0);
  const totalCompleted = payouts.filter(p => p.status === 'completed').reduce((sum, p) => sum + p.amount, 0);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Payout Management</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Process user payouts and manage payment requests
          </p>
        </div>
        
        <div className="flex space-x-3">
          {selectedPayouts.length > 0 && (
            <button
              onClick={handleBulkProcess}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
            >
              Process Selected ({selectedPayouts.length})
            </button>
          )}
          <button
            onClick={exportPayouts}
            className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Download className="w-4 h-4" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Pending Payouts</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                ${totalPending.toFixed(2)}
              </p>
              <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-1">
                {payouts.filter(p => p.status === 'pending').length} requests
              </p>
            </div>
            <div className="p-3 rounded-lg bg-yellow-500">
              <Clock className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Processing</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                ${totalProcessing.toFixed(2)}
              </p>
              <p className="text-xs text-blue-600 dark:text-blue-400 mt-1">
                {payouts.filter(p => p.status === 'processing').length} in progress
              </p>
            </div>
            <div className="p-3 rounded-lg bg-blue-500">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Completed</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                ${totalCompleted.toFixed(2)}
              </p>
              <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                {payouts.filter(p => p.status === 'completed').length} paid out
              </p>
            </div>
            <div className="p-3 rounded-lg bg-green-500">
              <CheckCircle className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Failed</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                {payouts.filter(p => p.status === 'failed').length}
              </p>
              <p className="text-xs text-red-600 dark:text-red-400 mt-1">
                Requires attention
              </p>
            </div>
            <div className="p-3 rounded-lg bg-red-500">
              <AlertTriangle className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <input
                type="text"
                placeholder="Search by user name or email..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
              />
            </div>
          </div>
          
          <div className="flex items-center space-x-2">
            <Filter className="w-4 h-4 text-gray-400" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value as any)}
              className="px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
            >
              <option value="all">All Status</option>
              <option value="pending">Pending</option>
              <option value="processing">Processing</option>
              <option value="completed">Completed</option>
              <option value="failed">Failed</option>
            </select>
          </div>
        </div>
      </div>

      {/* Payouts Table */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 dark:bg-gray-700">
              <tr>
                <th className="px-6 py-3 text-left">
                  <input
                    type="checkbox"
                    checked={selectedPayouts.length === filteredPayouts.filter(p => p.status === 'pending').length}
                    onChange={(e) => {
                      if (e.target.checked) {
                        setSelectedPayouts(filteredPayouts.filter(p => p.status === 'pending').map(p => p.id));
                      } else {
                        setSelectedPayouts([]);
                      }
                    }}
                    className="rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                  />
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  User
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Amount
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Method
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Status
                </th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Requested
                </th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody className="bg-white dark:bg-gray-800 divide-y divide-gray-200 dark:divide-gray-700">
              {filteredPayouts.map((payout) => (
                <tr key={payout.id} className="hover:bg-gray-50 dark:hover:bg-gray-700">
                  <td className="px-6 py-4 whitespace-nowrap">
                    <input
                      type="checkbox"
                      checked={selectedPayouts.includes(payout.id)}
                      onChange={(e) => {
                        if (e.target.checked) {
                          setSelectedPayouts(prev => [...prev, payout.id]);
                        } else {
                          setSelectedPayouts(prev => prev.filter(id => id !== payout.id));
                        }
                      }}
                      disabled={payout.status !== 'pending'}
                      className="rounded border-gray-300 text-blue-600 focus:ring-blue-500 disabled:opacity-50"
                    />
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div>
                      <div className="text-sm font-medium text-gray-900 dark:text-white">
                        {payout.userName}
                      </div>
                      <div className="text-sm text-gray-500 dark:text-gray-400">
                        {payout.email}
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm font-medium text-gray-900 dark:text-white">
                      ${payout.amount.toFixed(2)}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center space-x-2">
                      <CreditCard className="w-4 h-4 text-gray-400" />
                      <span className="text-sm text-gray-900 dark:text-white capitalize">
                        {payout.method}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(payout.status)}
                      <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getStatusColor(payout.status)}`}>
                        {payout.status}
                      </span>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                    {payout.requestedAt.toLocaleDateString()}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    {payout.status === 'pending' && (
                      <button
                        onClick={() => handleProcessPayout(payout.id)}
                        className="text-green-600 hover:text-green-900 dark:text-green-400 dark:hover:text-green-300"
                      >
                        Process
                      </button>
                    )}
                    {payout.status === 'completed' && (
                      <span className="text-green-600 dark:text-green-400">
                        Completed
                      </span>
                    )}
                    {payout.status === 'failed' && (
                      <button
                        onClick={() => handleProcessPayout(payout.id)}
                        className="text-blue-600 hover:text-blue-900 dark:text-blue-400 dark:hover:text-blue-300"
                      >
                        Retry
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {filteredPayouts.length === 0 && (
        <div className="text-center py-12">
          <DollarSign className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            No payouts found
          </h3>
          <p className="text-gray-600 dark:text-gray-400">
            {statusFilter === 'all' 
              ? 'No payout requests have been made yet'
              : `No ${statusFilter} payouts found`
            }
          </p>
        </div>
      )}
    </div>
  );
};

export default AdminPayouts;