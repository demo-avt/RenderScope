import React, { useState, useEffect } from 'react';
import { 
  Users, 
  TrendingUp, 
  DollarSign, 
  Image, 
  Globe,
  Activity,
  Eye,
  Play
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';

interface AdminMetrics {
  dailyActiveUsers: number;
  rendersToday: number;
  adFillRate: number;
  totalUsers: number;
  totalRenders: number;
  totalRevenue: number;
  averageRenderSize: number;
  topCountries: Array<{
    country: string;
    users: number;
    percentage: number;
  }>;
  rendersByHour: Array<{
    hour: number;
    renders: number;
  }>;
  revenueByDay: Array<{
    date: Date;
    revenue: number;
  }>;
}

const AdminDashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<AdminMetrics | null>(null);
  const [timeframe, setTimeframe] = useState<'24h' | '7d' | '30d'>('24h');

  useEffect(() => {
    // Mock admin metrics
    setMetrics({
      dailyActiveUsers: 1247,
      rendersToday: 3456,
      adFillRate: 94.2,
      totalUsers: 15678,
      totalRenders: 234567,
      totalRevenue: 12345.67,
      averageRenderSize: 2.4,
      topCountries: [
        { country: 'United States', users: 4567, percentage: 29.1 },
        { country: 'United Kingdom', users: 2345, percentage: 15.0 },
        { country: 'Germany', users: 1876, percentage: 12.0 },
        { country: 'Canada', users: 1234, percentage: 7.9 },
        { country: 'Australia', users: 987, percentage: 6.3 }
      ],
      rendersByHour: Array.from({ length: 24 }, (_, i) => ({
        hour: i,
        renders: Math.floor(Math.random() * 200) + 50
      })),
      revenueByDay: Array.from({ length: 30 }, (_, i) => ({
        date: new Date(Date.now() - (29 - i) * 24 * 60 * 60 * 1000),
        revenue: Math.floor(Math.random() * 500) + 200
      }))
    });
  }, []);

  if (!metrics) {
    return <div>Loading...</div>;
  }

  const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6'];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Admin Dashboard</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Monitor RenderWhizz platform performance and user activity
          </p>
        </div>
        
        <div className="flex space-x-2">
          {(['24h', '7d', '30d'] as const).map((period) => (
            <button
              key={period}
              onClick={() => setTimeframe(period)}
              className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                timeframe === period
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              {period}
            </button>
          ))}
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Daily Active Users</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                {metrics.dailyActiveUsers.toLocaleString()}
              </p>
              <p className="text-xs text-green-600 dark:text-green-400 mt-1">+12% from yesterday</p>
            </div>
            <div className="p-3 rounded-lg bg-blue-500">
              <Users className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Renders Today</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                {metrics.rendersToday.toLocaleString()}
              </p>
              <p className="text-xs text-green-600 dark:text-green-400 mt-1">+8% from yesterday</p>
            </div>
            <div className="p-3 rounded-lg bg-green-500">
              <Image className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Ad Fill Rate</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                {metrics.adFillRate}%
              </p>
              <p className="text-xs text-yellow-600 dark:text-yellow-400 mt-1">-2% from yesterday</p>
            </div>
            <div className="p-3 rounded-lg bg-purple-500">
              <Play className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Revenue</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                ${metrics.totalRevenue.toLocaleString()}
              </p>
              <p className="text-xs text-green-600 dark:text-green-400 mt-1">+15% this month</p>
            </div>
            <div className="p-3 rounded-lg bg-yellow-500">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Renders by Hour */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Renders by Hour</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={metrics.rendersByHour}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="hour" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(0, 0, 0, 0.8)', 
                    border: 'none', 
                    borderRadius: '8px',
                    color: 'white'
                  }}
                />
                <Bar dataKey="renders" fill="#3B82F6" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Revenue Trend */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Revenue Trend (30 Days)</h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={metrics.revenueByDay}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="date" className="text-xs" />
                <YAxis className="text-xs" />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'rgba(0, 0, 0, 0.8)', 
                    border: 'none', 
                    borderRadius: '8px',
                    color: 'white'
                  }}
                />
                <Line 
                  type="monotone" 
                  dataKey="revenue" 
                  stroke="#10B981" 
                  strokeWidth={2}
                  dot={{ fill: '#10B981', strokeWidth: 2, r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Bottom Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Top Countries */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Top Countries</h3>
          <div className="space-y-4">
            {metrics.topCountries.map((country, index) => (
              <div key={country.country} className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <div className={`w-3 h-3 rounded-full`} style={{ backgroundColor: COLORS[index] }}></div>
                  <span className="text-sm font-medium text-gray-900 dark:text-white">
                    {country.country}
                  </span>
                </div>
                <div className="text-right">
                  <p className="text-sm font-medium text-gray-900 dark:text-white">
                    {country.users.toLocaleString()}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {country.percentage}%
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* System Stats */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">System Stats</h3>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Total Users</span>
              <span className="font-medium text-gray-900 dark:text-white">
                {metrics.totalUsers.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Total Renders</span>
              <span className="font-medium text-gray-900 dark:text-white">
                {metrics.totalRenders.toLocaleString()}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Avg Render Size</span>
              <span className="font-medium text-gray-900 dark:text-white">
                {metrics.averageRenderSize} MB
              </span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">Server Uptime</span>
              <span className="font-medium text-green-600 dark:text-green-400">99.9%</span>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-sm text-gray-600 dark:text-gray-400">API Response Time</span>
              <span className="font-medium text-green-600 dark:text-green-400">145ms</span>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Recent Activity</h3>
          <div className="space-y-3">
            <div className="flex items-center space-x-3 text-sm">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-gray-600 dark:text-gray-400">New user registered</span>
              <span className="text-xs text-gray-500 dark:text-gray-400 ml-auto">2m ago</span>
            </div>
            <div className="flex items-center space-x-3 text-sm">
              <div className="w-2 h-2 bg-blue-500 rounded-full"></div>
              <span className="text-gray-600 dark:text-gray-400">Render uploaded</span>
              <span className="text-xs text-gray-500 dark:text-gray-400 ml-auto">5m ago</span>
            </div>
            <div className="flex items-center space-x-3 text-sm">
              <div className="w-2 h-2 bg-purple-500 rounded-full"></div>
              <span className="text-gray-600 dark:text-gray-400">Ad completed</span>
              <span className="text-xs text-gray-500 dark:text-gray-400 ml-auto">8m ago</span>
            </div>
            <div className="flex items-center space-x-3 text-sm">
              <div className="w-2 h-2 bg-yellow-500 rounded-full"></div>
              <span className="text-gray-600 dark:text-gray-400">Payout processed</span>
              <span className="text-xs text-gray-500 dark:text-gray-400 ml-auto">12m ago</span>
            </div>
            <div className="flex items-center space-x-3 text-sm">
              <div className="w-2 h-2 bg-green-500 rounded-full"></div>
              <span className="text-gray-600 dark:text-gray-400">WhatsApp sent</span>
              <span className="text-xs text-gray-500 dark:text-gray-400 ml-auto">15m ago</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;