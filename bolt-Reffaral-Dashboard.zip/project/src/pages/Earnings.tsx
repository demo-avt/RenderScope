import React, { useState, useEffect } from 'react';
import { DollarSign, TrendingUp, Calendar, Download, CreditCard } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

interface EarningsData {
  lifetime: number;
  pending: number;
  thisMonth: number;
  lastPayout: number;
  nextPayoutDate: Date;
  payoutThreshold: number;
  history: Array<{
    date: Date;
    amount: number;
    status: string;
  }>;
}

const Earnings: React.FC = () => {
  const [earnings, setEarnings] = useState<EarningsData | null>(null);
  const [timeframe, setTimeframe] = useState<'7d' | '30d' | '90d'>('30d');

  useEffect(() => {
    // Mock earnings data
    setEarnings({
      lifetime: 234.56,
      pending: 45.67,
      thisMonth: 67.89,
      lastPayout: 125.00,
      nextPayoutDate: new Date(Date.now() + 15 * 24 * 60 * 60 * 1000),
      payoutThreshold: 50.00,
      history: [
        { date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000), amount: 125.00, status: 'paid' },
        { date: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000), amount: 89.50, status: 'paid' },
        { date: new Date(Date.now() - 90 * 24 * 60 * 60 * 1000), amount: 156.75, status: 'paid' }
      ]
    });
  }, []);

  // Mock chart data
  const chartData = [
    { date: '2025-01-01', earnings: 12.34 },
    { date: '2025-01-02', earnings: 15.67 },
    { date: '2025-01-03', earnings: 8.90 },
    { date: '2025-01-04', earnings: 23.45 },
    { date: '2025-01-05', earnings: 18.76 },
    { date: '2025-01-06', earnings: 31.23 },
    { date: '2025-01-07', earnings: 27.89 }
  ];

  const referralBreakdown = [
    { tier: 'Tier 1 (Direct)', referrals: 23, earnings: 45.67, rate: '10%' },
    { tier: 'Tier 2 (Level 2)', referrals: 12, earnings: 18.34, rate: '5%' },
    { tier: 'Tier 3 (Level 3)', referrals: 5, earnings: 6.78, rate: '2%' }
  ];

  if (!earnings) {
    return <div>Loading...</div>;
  }

  const canRequestPayout = earnings.pending >= earnings.payoutThreshold;

  return (
    <div className="space-y-6">
      {/* Earnings Overview */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Lifetime Earnings</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                ${earnings.lifetime.toFixed(2)}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-green-500">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Pending Payout</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                ${earnings.pending.toFixed(2)}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                ${(earnings.payoutThreshold - earnings.pending).toFixed(2)} to threshold
              </p>
            </div>
            <div className="p-3 rounded-lg bg-yellow-500">
              <Calendar className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">This Month</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                ${earnings.thisMonth.toFixed(2)}
              </p>
              <p className="text-xs text-green-600 dark:text-green-400 mt-1">
                +23% from last month
              </p>
            </div>
            <div className="p-3 rounded-lg bg-blue-500">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Last Payout</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                ${earnings.lastPayout.toFixed(2)}
              </p>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                30 days ago
              </p>
            </div>
            <div className="p-3 rounded-lg bg-purple-500">
              <CreditCard className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Payout Section */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Payout Request</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Minimum payout: ${earnings.payoutThreshold.toFixed(2)}
            </p>
          </div>
          <button
            disabled={!canRequestPayout}
            className={`px-6 py-2 rounded-lg font-medium transition-colors ${
              canRequestPayout
                ? 'bg-green-600 hover:bg-green-700 text-white'
                : 'bg-gray-300 dark:bg-gray-600 text-gray-500 dark:text-gray-400 cursor-not-allowed'
            }`}
          >
            {canRequestPayout ? 'Request Payout' : 'Threshold Not Met'}
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium text-gray-900 dark:text-white mb-3">Payout Methods</h4>
            <div className="space-y-2">
              <label className="flex items-center space-x-3 p-3 border border-gray-200 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                <input type="radio" name="payout" value="stripe" defaultChecked className="text-blue-600" />
                <div className="flex items-center space-x-2">
                  <CreditCard className="w-4 h-4" />
                  <span className="text-sm font-medium">Stripe (Bank Transfer)</span>
                </div>
              </label>
              <label className="flex items-center space-x-3 p-3 border border-gray-200 dark:border-gray-600 rounded-lg cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700">
                <input type="radio" name="payout" value="paypal" className="text-blue-600" />
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-blue-600 rounded"></div>
                  <span className="text-sm font-medium">PayPal</span>
                </div>
              </label>
            </div>
          </div>

          <div>
            <h4 className="font-medium text-gray-900 dark:text-white mb-3">Next Payout</h4>
            <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
              <p className="text-sm text-blue-800 dark:text-blue-200">
                <strong>Estimated Date:</strong> {earnings.nextPayoutDate.toLocaleDateString()}
              </p>
              <p className="text-sm text-blue-700 dark:text-blue-300 mt-1">
                Payouts are processed on the 1st and 15th of each month
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Earnings Chart */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center justify-between mb-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Earnings Trend</h3>
          <div className="flex space-x-2">
            {(['7d', '30d', '90d'] as const).map((period) => (
              <button
                key={period}
                onClick={() => setTimeframe(period)}
                className={`px-3 py-1 text-sm rounded-lg transition-colors ${
                  timeframe === period
                    ? 'bg-blue-600 text-white'
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {period}
              </button>
            ))}
          </div>
        </div>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
              <XAxis dataKey="date" className="text-xs" />
              <YAxis className="text-xs" />
              <Tooltip 
                contentStyle={{ 
                  backgroundColor: 'rgba(0, 0, 0, 0.8)', 
                  border: 'none', 
                  borderRadius: '8px',
                  color: 'white'
                }}
              />
              <Line 
                type="monotone" 
                dataKey="earnings" 
                stroke="#3B82F6" 
                strokeWidth={2}
                dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
              />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Referral Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Referral Earnings</h3>
          <div className="space-y-4">
            {referralBreakdown.map((tier, index) => (
              <div key={index} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900 dark:text-white">{tier.tier}</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {tier.referrals} referrals • {tier.rate} commission
                  </p>
                </div>
                <p className="font-bold text-gray-900 dark:text-white">
                  ${tier.earnings.toFixed(2)}
                </p>
              </div>
            ))}
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Payout History</h3>
            <button className="flex items-center space-x-2 px-3 py-1 text-sm text-blue-600 hover:text-blue-700 dark:text-blue-400">
              <Download className="w-4 h-4" />
              <span>Export</span>
            </button>
          </div>
          <div className="space-y-3">
            {earnings.history.map((payout, index) => (
              <div key={index} className="flex items-center justify-between p-3 border border-gray-200 dark:border-gray-600 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900 dark:text-white">
                    ${payout.amount.toFixed(2)}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {payout.date.toLocaleDateString()}
                  </p>
                </div>
                <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200">
                  {payout.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Earnings;