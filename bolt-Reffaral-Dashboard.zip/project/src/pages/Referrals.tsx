import React, { useState, useEffect } from 'react';
import { Users, Share2, Copy, QrCode, TrendingUp, Gift } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface ReferralData {
  referralCode: string;
  shareUrl: string;
  totalReferrals: number;
  currentTier: number;
  commissionRate: number;
  totalEarnings: number;
  thisMonthEarnings: number;
  referrals: Array<{
    id: string;
    name: string;
    email: string;
    avatar: string;
    joinedAt: Date;
    totalRenders: number;
    earnings: number;
    status: 'active' | 'inactive';
  }>;
}

const Referrals: React.FC = () => {
  const { user } = useAuth();
  const [referralData, setReferralData] = useState<ReferralData | null>(null);
  const [showQR, setShowQR] = useState(false);

  useEffect(() => {
    // Mock referral data
    setReferralData({
      referralCode: user?.referralCode || 'RWUSER123',
      shareUrl: `https://renderwhizz.com/join/${user?.referralCode}`,
      totalReferrals: 23,
      currentTier: 2,
      commissionRate: 12,
      totalEarnings: 156.78,
      thisMonthEarnings: 34.56,
      referrals: [
        {
          id: '1',
          name: 'Alice Johnson',
          email: 'alice@example.com',
          avatar: 'https://images.pexels.com/photos/415829/pexels-photo-415829.jpeg?auto=compress&cs=tinysrgb&w=150',
          joinedAt: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
          totalRenders: 45,
          earnings: 45.67,
          status: 'active'
        },
        {
          id: '2',
          name: 'Bob Smith',
          email: 'bob@example.com',
          avatar: 'https://images.pexels.com/photos/614810/pexels-photo-614810.jpeg?auto=compress&cs=tinysrgb&w=150',
          joinedAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000),
          totalRenders: 23,
          earnings: 23.45,
          status: 'active'
        },
        {
          id: '3',
          name: 'Carol Davis',
          email: 'carol@example.com',
          avatar: 'https://images.pexels.com/photos/733872/pexels-photo-733872.jpeg?auto=compress&cs=tinysrgb&w=150',
          joinedAt: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000),
          totalRenders: 12,
          earnings: 12.34,
          status: 'inactive'
        }
      ]
    });
  }, [user]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // In production, show toast notification
    console.log('Copied to clipboard:', text);
  };

  const getTierInfo = (tier: number) => {
    const tiers = {
      1: { name: 'Bronze', range: '0-99', rate: '10%', color: 'bg-orange-500' },
      2: { name: 'Silver', range: '100-199', rate: '12%', color: 'bg-gray-400' },
      3: { name: 'Gold', range: '200-499', rate: '15%', color: 'bg-yellow-500' },
      4: { name: 'Platinum', range: '500-999', rate: '20%', color: 'bg-purple-500' },
      5: { name: 'Diamond', range: '1000+', rate: '20%', color: 'bg-blue-500' }
    };
    return tiers[tier as keyof typeof tiers] || tiers[1];
  };

  if (!referralData) {
    return <div>Loading...</div>;
  }

  const tierInfo = getTierInfo(referralData.currentTier);

  return (
    <div className="space-y-6">
      {/* Referral Overview */}
      <div className="bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">Referral Program</h1>
            <p className="text-purple-100 mb-4">
              Earn up to 20% commission on every referral's ad revenue. Build your network and grow your income!
            </p>
            <div className="flex items-center space-x-6 text-sm">
              <div className="flex items-center space-x-2">
                <Users className="w-4 h-4" />
                <span>{referralData.totalReferrals} Referrals</span>
              </div>
              <div className="flex items-center space-x-2">
                <div className={`w-3 h-3 rounded-full ${tierInfo.color}`}></div>
                <span>{tierInfo.name} Tier ({tierInfo.rate})</span>
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center">
              <Gift className="w-12 h-12" />
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Referrals</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                {referralData.totalReferrals}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-blue-500">
              <Users className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Commission Rate</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                {referralData.commissionRate}%
              </p>
            </div>
            <div className={`p-3 rounded-lg ${tierInfo.color}`}>
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Earnings</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                ${referralData.totalEarnings.toFixed(2)}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-green-500">
              <Gift className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">This Month</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                ${referralData.thisMonthEarnings.toFixed(2)}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-purple-500">
              <TrendingUp className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Share Section */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Share Your Referral Link</h3>
        
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
              Your Referral Code
            </label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={referralData.referralCode}
                readOnly
                className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white font-mono"
              />
              <button
                onClick={() => copyToClipboard(referralData.referralCode)}
                className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>

            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 mt-4">
              Share URL
            </label>
            <div className="flex space-x-2">
              <input
                type="text"
                value={referralData.shareUrl}
                readOnly
                className="flex-1 px-3 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-50 dark:bg-gray-700 text-gray-900 dark:text-white text-sm"
              />
              <button
                onClick={() => copyToClipboard(referralData.shareUrl)}
                className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <Copy className="w-4 h-4" />
              </button>
            </div>

            <div className="flex space-x-2 mt-4">
              <button
                onClick={() => setShowQR(!showQR)}
                className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
              >
                <QrCode className="w-4 h-4" />
                <span>QR Code</span>
              </button>
              <button className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors">
                <Share2 className="w-4 h-4" />
                <span>Share</span>
              </button>
            </div>
          </div>

          {showQR && (
            <div className="flex items-center justify-center">
              <div className="p-4 bg-white rounded-lg shadow-lg">
                <img
                  src={`https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(referralData.shareUrl)}`}
                  alt="QR Code"
                  className="w-48 h-48"
                />
                <p className="text-center text-sm text-gray-600 mt-2">Scan to join RenderWhizz</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Tier Progress */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Tier Progress</h3>
        
        <div className="space-y-4">
          {[1, 2, 3, 4, 5].map((tier) => {
            const info = getTierInfo(tier);
            const isCurrentTier = tier === referralData.currentTier;
            const isCompleted = tier < referralData.currentTier;
            
            return (
              <div key={tier} className={`flex items-center space-x-4 p-4 rounded-lg ${
                isCurrentTier ? 'bg-blue-50 dark:bg-blue-900/20 border-2 border-blue-200 dark:border-blue-800' : 'bg-gray-50 dark:bg-gray-700'
              }`}>
                <div className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  isCompleted ? 'bg-green-500' : isCurrentTier ? info.color : 'bg-gray-300 dark:bg-gray-600'
                }`}>
                  <span className="text-white font-bold text-sm">{tier}</span>
                </div>
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <h4 className="font-medium text-gray-900 dark:text-white">
                      {info.name} Tier
                    </h4>
                    <span className="text-sm font-medium text-gray-600 dark:text-gray-400">
                      {info.rate} Commission
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {info.range} referrals
                  </p>
                </div>
                {isCurrentTier && (
                  <span className="px-2 py-1 bg-blue-600 text-white text-xs rounded-full">
                    Current
                  </span>
                )}
                {isCompleted && (
                  <span className="px-2 py-1 bg-green-600 text-white text-xs rounded-full">
                    Completed
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Referrals List */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
        <div className="p-6 border-b border-gray-200 dark:border-gray-700">
          <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Your Referrals</h3>
          <p className="text-sm text-gray-600 dark:text-gray-400">People who joined using your referral link</p>
        </div>
        <div className="p-6">
          <div className="space-y-4">
            {referralData.referrals.map((referral) => (
              <div key={referral.id} className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                <div className="flex items-center space-x-4">
                  <img
                    src={referral.avatar}
                    alt={referral.name}
                    className="w-12 h-12 rounded-full"
                  />
                  <div>
                    <h4 className="font-medium text-gray-900 dark:text-white">{referral.name}</h4>
                    <p className="text-sm text-gray-600 dark:text-gray-400">{referral.email}</p>
                    <p className="text-xs text-gray-500 dark:text-gray-400">
                      Joined {referral.joinedAt.toLocaleDateString()}
                    </p>
                  </div>
                </div>
                <div className="text-right">
                  <p className="font-medium text-gray-900 dark:text-white">
                    ${referral.earnings.toFixed(2)}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    {referral.totalRenders} renders
                  </p>
                  <span className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
                    referral.status === 'active'
                      ? 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
                      : 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
                  }`}>
                    {referral.status}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Referrals;