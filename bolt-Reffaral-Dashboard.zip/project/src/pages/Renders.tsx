import React, { useState, useEffect } from 'react';
import { Image, Upload, Play, CheckCircle, Clock, Smartphone, Download } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';

interface Render {
  id: string;
  filename: string;
  thumbnail: string;
  uploadedAt: Date;
  adWatched: boolean;
  status: 'pending' | 'sent' | 'failed';
  whatsappSent: boolean;
  filesize?: number;
}

const Renders: React.FC = () => {
  const [renders, setRenders] = useState<Render[]>([]);
  const [filter, setFilter] = useState<'all' | 'sent' | 'pending' | 'failed'>('all');
  const [isUploading, setIsUploading] = useState(false);

  useEffect(() => {
    // Mock render data
    setRenders([
      {
        id: '1',
        filename: 'bedroom_render_001.jpg',
        thumbnail: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=300',
        uploadedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
        adWatched: true,
        status: 'sent',
        whatsappSent: true,
        filesize: 2.4 * 1024 * 1024
      },
      {
        id: '2',
        filename: 'kitchen_render_002.jpg',
        thumbnail: 'https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg?auto=compress&cs=tinysrgb&w=300',
        uploadedAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
        adWatched: true,
        status: 'sent',
        whatsappSent: true,
        filesize: 3.1 * 1024 * 1024
      },
      {
        id: '3',
        filename: 'living_room_003.jpg',
        thumbnail: 'https://images.pexels.com/photos/1571453/pexels-photo-1571453.jpeg?auto=compress&cs=tinysrgb&w=300',
        uploadedAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
        adWatched: true,
        status: 'sent',
        whatsappSent: true,
        filesize: 1.8 * 1024 * 1024
      },
      {
        id: '4',
        filename: 'bathroom_render_004.jpg',
        thumbnail: 'https://images.pexels.com/photos/1454804/pexels-photo-1454804.jpeg?auto=compress&cs=tinysrgb&w=300',
        uploadedAt: new Date(Date.now() - 48 * 60 * 60 * 1000),
        adWatched: false,
        status: 'pending',
        whatsappSent: false,
        filesize: 2.7 * 1024 * 1024
      }
    ]);
  }, []);

  const filteredRenders = renders.filter(render => {
    if (filter === 'all') return true;
    return render.status === filter;
  });

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    
    // Mock upload process
    setTimeout(() => {
      const newRender: Render = {
        id: Date.now().toString(),
        filename: file.name,
        thumbnail: URL.createObjectURL(file),
        uploadedAt: new Date(),
        adWatched: false,
        status: 'pending',
        whatsappSent: false,
        filesize: file.size
      };
      
      setRenders(prev => [newRender, ...prev]);
      setIsUploading(false);
    }, 2000);
  };

  const watchAdAndSend = (renderId: string) => {
    // Mock ad watching process
    setRenders(prev => prev.map(render => 
      render.id === renderId 
        ? { ...render, adWatched: true, status: 'sent', whatsappSent: true }
        : render
    ));
  };

  const formatFileSize = (bytes: number) => {
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(1)} MB`;
  };

  const getStatusIcon = (render: Render) => {
    switch (render.status) {
      case 'sent':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'pending':
        return <Clock className="w-5 h-5 text-yellow-500" />;
      case 'failed':
        return <div className="w-5 h-5 rounded-full bg-red-500"></div>;
      default:
        return <Clock className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusText = (render: Render) => {
    switch (render.status) {
      case 'sent':
        return 'Sent to WhatsApp';
      case 'pending':
        return render.adWatched ? 'Processing...' : 'Watch ad to send';
      case 'failed':
        return 'Failed to send';
      default:
        return 'Unknown';
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Your Renders</h1>
          <p className="text-gray-600 dark:text-gray-400">
            Upload renders and watch ads to send them to WhatsApp
          </p>
        </div>
        
        <label className="flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors cursor-pointer">
          <Upload className="w-4 h-4" />
          <span>{isUploading ? 'Uploading...' : 'Upload Render'}</span>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileUpload}
            className="hidden"
            disabled={isUploading}
          />
        </label>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Total Renders</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">{renders.length}</p>
            </div>
            <div className="p-3 rounded-lg bg-blue-500">
              <Image className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Sent Successfully</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                {renders.filter(r => r.status === 'sent').length}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-green-500">
              <CheckCircle className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Pending</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                {renders.filter(r => r.status === 'pending').length}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-yellow-500">
              <Clock className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Ads Watched</p>
              <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">
                {renders.filter(r => r.adWatched).length}
              </p>
            </div>
            <div className="p-3 rounded-lg bg-purple-500">
              <Play className="w-6 h-6 text-white" />
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <div className="flex items-center space-x-4">
          <span className="text-sm font-medium text-gray-700 dark:text-gray-300">Filter:</span>
          {(['all', 'sent', 'pending', 'failed'] as const).map((filterOption) => (
            <button
              key={filterOption}
              onClick={() => setFilter(filterOption)}
              className={`px-3 py-1 text-sm rounded-lg transition-colors capitalize ${
                filter === filterOption
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-600 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-600'
              }`}
            >
              {filterOption} ({filterOption === 'all' ? renders.length : renders.filter(r => r.status === filterOption).length})
            </button>
          ))}
        </div>
      </div>

      {/* Renders Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredRenders.map((render) => (
          <div key={render.id} className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 overflow-hidden">
            {/* Image */}
            <div className="aspect-video bg-gray-100 dark:bg-gray-700 relative">
              <img
                src={render.thumbnail}
                alt={render.filename}
                className="w-full h-full object-cover"
              />
              <div className="absolute top-2 right-2 flex space-x-1">
                {render.whatsappSent && (
                  <div className="p-1 bg-green-500 rounded-full">
                    <Smartphone className="w-3 h-3 text-white" />
                  </div>
                )}
                {render.adWatched && (
                  <div className="p-1 bg-purple-500 rounded-full">
                    <Play className="w-3 h-3 text-white" />
                  </div>
                )}
              </div>
            </div>

            {/* Content */}
            <div className="p-4">
              <h3 className="font-medium text-gray-900 dark:text-white truncate mb-2">
                {render.filename}
              </h3>
              
              <div className="flex items-center justify-between text-sm text-gray-600 dark:text-gray-400 mb-3">
                <span>{formatDistanceToNow(render.uploadedAt, { addSuffix: true })}</span>
                {render.filesize && <span>{formatFileSize(render.filesize)}</span>}
              </div>

              <div className="flex items-center justify-between mb-3">
                <div className="flex items-center space-x-2">
                  {getStatusIcon(render)}
                  <span className="text-sm font-medium text-gray-700 dark:text-gray-300">
                    {getStatusText(render)}
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="flex space-x-2">
                {render.status === 'pending' && !render.adWatched && (
                  <button
                    onClick={() => watchAdAndSend(render.id)}
                    className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors text-sm"
                  >
                    <Play className="w-4 h-4" />
                    <span>Watch Ad & Send</span>
                  </button>
                )}
                
                {render.status === 'sent' && (
                  <button className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-600 transition-colors text-sm">
                    <Download className="w-4 h-4" />
                    <span>Download</span>
                  </button>
                )}
                
                {render.status === 'failed' && (
                  <button
                    onClick={() => watchAdAndSend(render.id)}
                    className="flex-1 flex items-center justify-center space-x-2 px-3 py-2 bg-red-600 text-white rounded-lg hover:bg-red-700 transition-colors text-sm"
                  >
                    <Play className="w-4 h-4" />
                    <span>Retry</span>
                  </button>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>

      {filteredRenders.length === 0 && (
        <div className="text-center py-12">
          <Image className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">
            {filter === 'all' ? 'No renders yet' : `No ${filter} renders`}
          </h3>
          <p className="text-gray-600 dark:text-gray-400 mb-4">
            {filter === 'all' 
              ? 'Upload your first render to get started'
              : `No renders with ${filter} status found`
            }
          </p>
          {filter === 'all' && (
            <label className="inline-flex items-center space-x-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors cursor-pointer">
              <Upload className="w-4 h-4" />
              <span>Upload Your First Render</span>
              <input
                type="file"
                accept="image/*"
                onChange={handleFileUpload}
                className="hidden"
                disabled={isUploading}
              />
            </label>
          )}
        </div>
      )}
    </div>
  );
};

export default Renders;