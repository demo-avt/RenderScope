import React, { useState, useEffect } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  Users, 
  Image, 
  Play, 
  CheckCircle,
  Clock,
  Smartphone
} from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface DashboardStats {
  totalRenders: number;
  totalEarnings: number;
  totalReferrals: number;
  adsWatched: number;
  thisWeekRenders: number;
  thisWeekEarnings: number;
}

const Dashboard: React.FC = () => {
  const { user } = useAuth();
  const [stats, setStats] = useState<DashboardStats>({
    totalRenders: 0,
    totalEarnings: 0,
    totalReferrals: 0,
    adsWatched: 0,
    thisWeekRenders: 0,
    thisWeekEarnings: 0
  });
  const [recentRenders, setRecentRenders] = useState([]);

  useEffect(() => {
    // Mock data - in production, fetch from API
    setStats({
      totalRenders: 156,
      totalEarnings: 78.45,
      totalReferrals: 23,
      adsWatched: 156,
      thisWeekRenders: 12,
      thisWeekEarnings: 6.75
    });

    setRecentRenders([
      {
        id: '1',
        filename: 'bedroom_render_001.jpg',
        thumbnail: 'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=300',
        uploadedAt: new Date(Date.now() - 2 * 60 * 60 * 1000),
        status: 'sent'
      },
      {
        id: '2',
        filename: 'kitchen_render_002.jpg',
        thumbnail: 'https://images.pexels.com/photos/1080721/pexels-photo-1080721.jpeg?auto=compress&cs=tinysrgb&w=300',
        uploadedAt: new Date(Date.now() - 5 * 60 * 60 * 1000),
        status: 'sent'
      },
      {
        id: '3',
        filename: 'living_room_003.jpg',
        thumbnail: 'https://images.pexels.com/photos/1571453/pexels-photo-1571453.jpeg?auto=compress&cs=tinysrgb&w=300',
        uploadedAt: new Date(Date.now() - 24 * 60 * 60 * 1000),
        status: 'sent'
      }
    ]);
  }, []);

  const StatCard = ({ icon: Icon, title, value, subtitle, color }: any) => (
    <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 border border-gray-200 dark:border-gray-700">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600 dark:text-gray-400">{title}</p>
          <p className="text-2xl font-bold text-gray-900 dark:text-white mt-1">{value}</p>
          {subtitle && (
            <p className="text-sm text-gray-500 dark:text-gray-400 mt-1">{subtitle}</p>
          )}
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          <Icon className="w-6 h-6 text-white" />
        </div>
      </div>
    </div>
  );

  return (
    <div className="space-y-6">
      {/* Welcome Section */}
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">
              Welcome back, {user?.name?.split(' ')[0]}! 🎨
            </h1>
            <p className="text-blue-100 mb-4">
              Your renders are ready to be shared. Watch ads to unlock WhatsApp sending.
            </p>
            <div className="flex items-center space-x-4 text-sm">
              <div className="flex items-center space-x-2">
                <CheckCircle className="w-4 h-4" />
                <span>WhatsApp {user?.whatsappVerified ? 'Verified' : 'Not Verified'}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Users className="w-4 h-4" />
                <span>Tier {Math.floor(stats.totalReferrals / 100) + 1} Referrer</span>
              </div>
            </div>
          </div>
          <div className="hidden md:block">
            <div className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center">
              <Image className="w-12 h-12" />
            </div>
          </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard
          icon={Image}
          title="Total Renders"
          value={stats.totalRenders}
          subtitle={`+${stats.thisWeekRenders} this week`}
          color="bg-blue-500"
        />
        <StatCard
          icon={DollarSign}
          title="Total Earnings"
          value={`$${stats.totalEarnings.toFixed(2)}`}
          subtitle={`+$${stats.thisWeekEarnings.toFixed(2)} this week`}
          color="bg-green-500"
        />
        <StatCard
          icon={Users}
          title="Referrals"
          value={stats.totalReferrals}
          subtitle={`${Math.floor(stats.totalReferrals / 100) + 1}x tier multiplier`}
          color="bg-purple-500"
        />
        <StatCard
          icon={Play}
          title="Ads Watched"
          value={stats.adsWatched}
          subtitle="100% completion rate"
          color="bg-orange-500"
        />
      </div>

      {/* Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Renders */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Recent Renders</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">Your latest render uploads</p>
          </div>
          <div className="p-6 space-y-4">
            {recentRenders.map((render: any) => (
              <div key={render.id} className="flex items-center space-x-4">
                <img
                  src={render.thumbnail}
                  alt={render.filename}
                  className="w-12 h-12 rounded-lg object-cover"
                />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 dark:text-white truncate">
                    {render.filename}
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-400">
                    {new Date(render.uploadedAt).toLocaleString()}
                  </p>
                </div>
                <div className="flex items-center space-x-2">
                  <CheckCircle className="w-4 h-4 text-green-500" />
                  <Smartphone className="w-4 h-4 text-blue-500" />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Quick Actions */}
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700">
          <div className="p-6 border-b border-gray-200 dark:border-gray-700">
            <h3 className="text-lg font-semibold text-gray-900 dark:text-white">Quick Actions</h3>
            <p className="text-sm text-gray-600 dark:text-gray-400">Common tasks and shortcuts</p>
          </div>
          <div className="p-6 space-y-4">
            <button className="w-full flex items-center space-x-3 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg hover:bg-blue-100 dark:hover:bg-blue-900/30 transition-colors">
              <div className="w-10 h-10 bg-blue-500 rounded-lg flex items-center justify-center">
                <Image className="w-5 h-5 text-white" />
              </div>
              <div className="text-left">
                <p className="font-medium text-gray-900 dark:text-white">Upload New Render</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Watch ad and send to WhatsApp</p>
              </div>
            </button>

            <button className="w-full flex items-center space-x-3 p-4 bg-green-50 dark:bg-green-900/20 rounded-lg hover:bg-green-100 dark:hover:bg-green-900/30 transition-colors">
              <div className="w-10 h-10 bg-green-500 rounded-lg flex items-center justify-center">
                <Users className="w-5 h-5 text-white" />
              </div>
              <div className="text-left">
                <p className="font-medium text-gray-900 dark:text-white">Share Referral Link</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Earn up to 20% commission</p>
              </div>
            </button>

            <button className="w-full flex items-center space-x-3 p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg hover:bg-purple-100 dark:hover:bg-purple-900/30 transition-colors">
              <div className="w-10 h-10 bg-purple-500 rounded-lg flex items-center justify-center">
                <DollarSign className="w-5 h-5 text-white" />
              </div>
              <div className="text-left">
                <p className="font-medium text-gray-900 dark:text-white">View Earnings</p>
                <p className="text-sm text-gray-600 dark:text-gray-400">Track your revenue</p>
              </div>
            </button>
          </div>
        </div>
      </div>

      {/* Plugin Status */}
      <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm border border-gray-200 dark:border-gray-700 p-6">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Plugin Status</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="flex items-center justify-between p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <span className="font-medium text-gray-900 dark:text-white">3ds Max Plugin</span>
            </div>
            <span className="text-sm text-green-600 dark:text-green-400">Connected</span>
          </div>
          <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 bg-gray-400 rounded-full"></div>
              <span className="font-medium text-gray-900 dark:text-white">Unreal Engine Plugin</span>
            </div>
            <span className="text-sm text-gray-500 dark:text-gray-400">Not Connected</span>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;